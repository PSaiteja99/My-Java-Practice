package org;

public class Countdigandalpusingmethods 
{
		public static void sort_char(String s)
		{
		int alphacount=0;
		int digitcount=0;
		for (int i=0;i<=s.length()-1;i++)
		{
			char c= s.charAt(i);
			if(c>='A' && c<='Z' ||   c>='a' && c<='z' )
			{
				alphacount++;
			}
			if( c>='0'&& c<='9')
			{
				digitcount++;
			}
		}
		System.out.println("The count of vowels is :"+alphacount);
		System.out.println(" The count of digit  is :"+digitcount);
		}
		
	public static void main(String[] args) 
	{
		String s="vybhav123";
		if (s.isEmpty())
		{
			System.out.println("String is empty no charecter in the String");
		}
		else 
		{
			sort_char(s);
		}
	}
	}