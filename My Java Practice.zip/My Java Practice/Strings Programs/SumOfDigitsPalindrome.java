import java.util.Scanner;

public class SumOfDigitsPalindrome {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

        int sum = 0;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (Character.isDigit(c)) {
                sum += Character.getNumericValue(c);
            }
        }

        System.out.println("Sum of digits: " + sum);

        int originalSum = sum;
        int reversedSum = 0;
        while (sum > 0) {
            int digit = sum % 10;
            reversedSum = reversedSum * 10 + digit;
            sum /= 10;
        }

        if (originalSum == reversedSum) {
            System.out.println("The sum of digits is a palindrome.");
        } else {
            System.out.println("The sum of digits is not a palindrome.");
        }

        scanner.close();
    }
}
