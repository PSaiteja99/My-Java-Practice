package org;

import java.util.Scanner;
public class CountAlpvowelsandDig
{
    public static boolean isEmpty(String s) 
    {
        return s.length() == 0;
    }

    public static void countalpvowanddig(String s) 
    {
        int vowelCount = 0;
        int alphabetCount = 0;
        int digitCount = 0;

        for (int i = 0; i < s.length(); i++) 
        {
            char ch = s.charAt(i);
            if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) 
            {
                alphabetCount++;
                if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u'
                        || ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U') 
                {
                    vowelCount++;
                }
            } 
            else if (ch >= '0' && ch <= '9') 
            {
                digitCount++;
            }
        }
        System.out.println("Number of alphabets: " + alphabetCount);
        System.out.println("Number of vowels: " + vowelCount);
        System.out.println("Number of digits: " + digitCount);
    }

    public static void main(String[] args)
    {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter a string:");
        String v = s.nextLine();
        if (isEmpty(v)) 
        {
            System.out.println("Input string is empty.");
        }
        else 
        {
        	countalpvowanddig(v);
        }
    }
}




