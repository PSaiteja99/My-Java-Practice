package org;

import java.util.Scanner;
public class Palindromecheckmethod 
{
	 public static boolean isEmpty(String str)
	 {
	        return str.length() == 0;
	    }

	    public static boolean checkPalindrome(String str)
	    {
	        int temp = Integer.parseInt(str);
	        int rev = 0;
	        while (temp != 0) 
	        {
	            int ld = temp % 10;
	            rev = rev * 10 + ld;
	            temp = temp / 10;
	        }
	        String revStr = Integer.toString(rev);
	        return str.equals(revStr);
	    }


	    public static void main(String[] args) 
	    {
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter a string:");
	        String str = sc.next();

	        if (!isEmpty(str)) 
	        {
	            if (checkPalindrome(str))
	            {
	                System.out.println("It is a palindrome");
	            } 
	            else 
	            {
	                System.out.println("It is not a palindrome");
	            }
	        } 
	        
	    }
	    }

	   