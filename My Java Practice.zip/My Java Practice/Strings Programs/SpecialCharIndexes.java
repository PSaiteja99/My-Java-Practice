import java.util.Scanner;

public class SpecialCharIndexes {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

        System.out.println("Index positions of special characters:");

        boolean foundSpecialChar = false;

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (!Character.isLetterOrDigit(c) && !Character.isWhitespace(c)) {
                System.out.println("'" + c + "' at index " + i);
                foundSpecialChar = true;
            }
        }

        if (!foundSpecialChar) {
            System.out.println("No special characters found in the string.");
        }

        scanner.close();
    }
}
