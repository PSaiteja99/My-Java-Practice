package org;

public class countdigandalpha {
	
		public static void main(String[] args) 
		{
		String s="Jsp123";
		int  alphacount=0;
		int  digitcount=0;
		for(int i=0;i<=s.length()-1;i++)
		{
			char ch=s.charAt(i);
			if(ch>='A' && ch<='Z' ||   ch>='a' && ch<='z' )
			{
				alphacount++;
			}
			if( ch>='0'&& ch<='9')
			{
				digitcount++;
			}
		}
		System.out.println(alphacount);
		System.out.println(digitcount);
	}
	}


