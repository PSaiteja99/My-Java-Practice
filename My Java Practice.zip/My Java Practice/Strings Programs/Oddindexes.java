package org;

public class Oddindexes 
{
    public static void main(String[] args)
    {
        String s = "I_am_a_Indian";
        String[] str = s.split("_");
        for (int i = 0; i < str.length; i++)
        {
            if (i % 2 != 0)
            {
                System.out.print(str[i] + " ");
            }
        }
    }
}
