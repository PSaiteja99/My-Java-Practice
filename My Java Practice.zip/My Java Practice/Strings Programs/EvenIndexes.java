package org;

public class EvenIndexes 
{
	public static void main(String[] args) 
	{
	String s="VYBHAV";	
	for(int i=1;i<=s.length()-1;i++)
	{

		if(i%2==0)
		{
		System.err.println(s.charAt(i));
		}
	}
	}
}
