package org;

public class RemoveSpaces 
{
public static void main(String[] args)
{
	String s="JA VA";
	char oldchar=' ';
	String newchar="";
	String res="";
	for(int i=0;i<=s.length()-1;i++)
	{
		char ch=s.charAt(i);
		if(s.charAt(i)==oldchar)
		{
			res=res+newchar;
		}
		else
		{
			res=res+s.charAt(i);
		}
}
	System.out.println(res);
}
}

