package org;
public class Evenindmethod
{
	public static boolean isEmpty(String s)
    {
        return s.length() == 0;
    }

    public static void printEvenIndexCharacters(String s)
    {
        for (int i = 0; i < s.length(); i++) 
        {
            if (i % 2 == 0) 
            {
                System.out.println(s.charAt(i));
            }
        }
    }
    public static void main(String[] args) 
    {
        String s = "VYBHAV";
        if (!isEmpty(s)) 
        {
            printEvenIndexCharacters(s);
        } 
        else 
        {
            System.out.println("Input string is empty.");
        }
    }

    }


