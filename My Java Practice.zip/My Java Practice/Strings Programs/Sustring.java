package org;

public class Sustring 
{
	public static void main(String[] args)
	{
String s="Java Developer";
String res=s.substring(5);
System.out.println(res);

}
}
