package org;

public class Vowelsindex {
    public static void main(String[] args) {
        String s = "I am a developer";
        int vowelCount = 0;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || 
                ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U') {
                vowelCount++;
                System.out.println("Vowel found at index: " + i);
            }
        }
        System.out.println("Total vowel count: " + vowelCount);
    }
}


