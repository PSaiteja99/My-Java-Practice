package org;

public class Reverseword
{
/*public static void main(String[] args) 
{	
String s="Chakka vybhav kumar";
String[] s1=s.split(" ");
for(int i=s1.length-1;i>=0;i--)
{
System.out.print(s1[i]+" ");l

}
}
}*/

  public static void reverse(String s)
	{
	  String[] s1=s.split(" ");
	  for(int i=s1.length-1;i>=0;i--)
	  {
	  System.out.print(s1[i]+" ");
	  } 
	}
	public static void main(String[] args) 
	{
	String s="chakka vybhav kumar";	
	reverse(s);
	}
}
