package org;

public class Checkpalindrome {

}
