package org;

import java.util.Scanner;

public class Palindromeornot
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string:");
        String str = sc.next();
        int temp = Integer.parseInt(str); 
        int rev = 0;
        while (temp != 0)
        {
            int ld = temp % 10;
            rev = rev * 10 + ld;
            temp = temp / 10;
        }
        System.out.println("Reverse value:" + rev);
        System.out.println("Given String:" + str);
        String revStr = Integer.toString(rev);
        if (str.equals(revStr)) 
        {
            System.out.println("It is a palindrome");
        } 
        else
        {
            System.out.println("It is not a palindrome");
        }
    }
}


