package org;

public class LengthofString 
{
public static void main(String[] args) 
{
String s="JavaC";	
for(int i=0;i<=s.length()-1;i++)
{
	char ch=s.charAt(i);
	System.err.println(ch);
}
}
}
