package org;

public class AsciiMethoduse 
{
	 public static boolean isEmpty(String s) {
	        return s.length() == 0;
	    }

	    public static int calculateAsciiSum(String s) {
	        int sum = 0;
	        for (char ch : s.toCharArray()) {
	            sum += ch;
	        }
	        return sum;
	    }

    public static void main(String[] args)
    {
        String s = "ABCD";
        if (!isEmpty(s))
        {
            int asciiSum = calculateAsciiSum(s);
            System.out.println("Sum of ASCII values: " + asciiSum);
        } 
        else
        {
            System.out.println("Input string is empty.");
        }
    }
}

   