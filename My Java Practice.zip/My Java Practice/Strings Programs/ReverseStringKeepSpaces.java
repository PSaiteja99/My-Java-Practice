import java.util.Scanner;

public class ReverseStringKeepSpaces {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

        char[] charArray = input.toCharArray();
        char[] result = new char[charArray.length];

        for (int i = 0; i < charArray.length; i++) {
            if (charArray[i] == ' ') {
                result[i] = ' ';
            }
        }

        int j = result.length - 1;
        for (int i = 0; i < charArray.length; i++) {
            if (charArray[i] != ' ') {
                if (result[j] == ' ') {
                    j--;
                }
                result[j] = charArray[i];
                j--;
            }
        }

        String reversed = new String(result);
        System.out.println("Reversed string: " + reversed);

        scanner.close();
    }
}
