package org;

public class DgitPalindrome 
{
public static void main(String[] args) 
{
String s="J12s345p";
String s1="";
for(int i=0;i<=s.length()-1;i++)
{
	 char ch=s.charAt(i);
	 if(Character.isDigit(ch))
	 {
	 s1=s1+ch;
	 }
}
System.out.println(s1);
System.out.println("Digits only: " + s1);
if (isPalindrome(s1)) 
{
    System.out.println("The digit substring is a palindrome.");
} else {
    System.out.println("The digit substring is not a palindrome.");
}
}

public static boolean isPalindrome(String s)
{
    int start = 0;
    int end = s.length() - 1;
    while (start < end) 
    {
        if (s.charAt(start) != s.charAt(end))
        {
            return false;
        }
        start++;
        end--;
    }
    return true;
}
}


