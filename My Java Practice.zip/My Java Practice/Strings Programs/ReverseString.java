package org;

public class ReverseString 
{
	public static void main(String[] args)
	{
	String s="this is india";	
	String[] str=s.split("");
	for(int i=s.length()-1;i>=0;i--)
	{
	System.out.println(str[i]);
	}
	}
}
