import java.util.Scanner;
class  SimpleIntrest
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("SIMPLE INTREST CALCULATION");
		System.out.println("==========================");
		System.out.println("enter principal amount:");
		double p=sc.nextDouble();
		System.out.println("enter time period: ");
		double t=sc.nextDouble();
		System.out.println("enter rate of intrest :");
		double r=sc.nextDouble();
		System.out.println("================");
		double si=(p*t*r)/100;
		System.out.println("principal"+p);
		System.out.println(si);
		System.out.println("total:"+(p+si));
		System.out.println("SIMPLE INTREST CALCULATION");

	}
}
