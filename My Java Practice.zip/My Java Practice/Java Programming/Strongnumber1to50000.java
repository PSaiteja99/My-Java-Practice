class Strongnumber1to50000 
{
	public static void main(String[] args) 
	{
		for (int num=1;num<=50000;num++ )
		{
		int temp=num;
		int sum=0;
		while (temp!=0)
		{
			int ld=temp%10;
			int prod=1;
			for (int i=1;i<=ld;i++ )
			{
				prod=prod*i;
			}
			sum=sum+prod;
			temp=temp/10;
		}
    
		if (num==sum)
		{
		
		System.out.println(num);
		}
		}
	}
}
