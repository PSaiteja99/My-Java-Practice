class MergeofArrayeven 
	{
    public static void main(String[] args)
		{
        int[] a = {1, 2, 3, 4};
        int[] b = {5, 6, 7, 8, 9};
        int[] c = new int[a.length + b.length];
        int index = 0;
        for (int i = 0; i < a.length; i++)
			{
            if (a[i] % 2 == 0) 
				{
                c[index++] = a[i];
            }
        }
        for (int i = 0; i < b.length; i++) 
			{
            if (b[i] % 2 == 0)
				{
                c[index++] = b[i];
            }
        }

        System.out.println("Merged even elements:");
        for (int i = 0; i < index; i++) 
			{
            System.out.println(c[i]);
        }
    }
}
