import java.util.Scanner;

class Uniquenumber1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number: ");
        int n = sc.nextInt();
        boolean isUnique = true;  // Assume the number is unique initially

        // Create a set to track digits already encountered
        boolean[] digitsSeen = new boolean[10];

        while (n != 0) {
            int ld = n % 10; // Get the last digit of the number

            if (digitsSeen[ld]) {
                // If the digit has already been encountered, it's not unique
                isUnique = false;
                break;
            }

            // Mark the digit as seen
            digitsSeen[ld] = true;

            // Remove the last digit from the number
            n = n / 10;
        }

        // Output the result based on whether the number is unique
        if (isUnique) {
            System.out.println("It is a unique number");
        } else {
            System.out.println("It is not a unique number");
        }

        sc.close();
    }
}
