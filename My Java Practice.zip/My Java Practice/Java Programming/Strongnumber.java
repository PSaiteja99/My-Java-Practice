import java.util.Scanner;
class Strongnumber 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
        System.out.println("enter a number:");
        int num=sc.nextInt();
		int temp=num;
		int sum=0;
		while (temp!=0)
		{
			int ld=temp%10;
			int prod=1;
			for (int i=1;i<=ld;i++ )
			{
				prod=prod*i;
			}
			sum=sum+prod;
			temp=temp/10;
		}
			   if (sum == num)
				   {
                System.out.println(num + " is a Strong Number");
            }
			else
				{
                System.out.println(num + " is not a Strong Number");
            }

	}
}
