import java.util.Scanner;
class Firstnprimenumbers 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		int a=sc.nextInt();
		int b=0;
		for (int i=1;i<=a;i++)
		{
		int c=0;
		for (int j=1;j<=i;j++)
		{
			if (i%j==0)
			{
				c++;

			 }
		}
		if (c==2)
		{
			b++;
			System.out.println(i);
			
	     }
		}

	}
}


