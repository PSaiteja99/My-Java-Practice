class Primeelementsinarray1
{
    public static void main(String[] args) 
    {
        int[] a = {4, 5, 2, 7, 9};  
        int count;
        for (int j = 0; j < a.length; j++) 
        {
   
            if (a[j] < 2) 
			{
				continue;
			}
			count = 0; 
            for (int i = 1; i <= a[j]; i++) 
            {
                if (a[j] % i == 0) 
                {
                    count++; 
                }
            }
            if (count == 2) 
            {
                System.out.println(a[j]);
            }
        }
    }
}
