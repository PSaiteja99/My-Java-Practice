import java.util.Scanner;
class FactorialrecursionLong
{
	public static Long fact(Long n)
	{
		if(n==0)
			return 0;
		else
			return n*fact(n-1);
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number:");
		Long n=sc.nextLong();
		System.out.println(fact(n));
	}
}
