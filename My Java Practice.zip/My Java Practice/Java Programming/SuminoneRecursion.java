import java.util.Scanner;
class  SuminoneRecursion
{
	public static boolean SumofDigits(int n)
	{
	 if(n<=9)
		{
		 if (n==1)
			 return true;
		 else
			 return false;
		}
		 
		else
		{
			int sum=0;
			while(n>0)
			{
				sum=sum+(n%10);
				n=n/10;
			}
				return SumofDigits(sum);
		}
	}

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		int n=sc.nextInt();
		System.out.println(SumofDigits(n));
	}
}