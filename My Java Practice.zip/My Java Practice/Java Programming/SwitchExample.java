import java.util.Scanner;
class SwitchExample
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the grade of students:");
		char grade=sc.next().charAt(0);
		switch(grade)
		{
		case 'A':case 'a': System.out.println("you got first rank");
		case 'B':case 'b': System.out.println("you got second rank");
		case 'C':case 'c': System.out.println("you got first class");
		case 'D':case 'd': System.out.println("you got second class");
		case 'E':case 'e': System.out.println("you just passed the exam");
		case 'F':case 'f': System.out.println("you failed the exam");
		default:System.out.println("Enter valid operator");


		
		}
	}
}

