import java.util.Scanner;
class Datefashionrating
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a value");
		int a=sc.nextInt();
		System.out.println("enter b value");
		int b=sc.nextInt();
		if(a<=2||b<=2)
		{
			System.out.println("0");
		}
		else if(a>=8||b>=8)
		{
			System.out.println("2");
		}
		else 
		{
			System.out.println("1");
		}
	}
}
