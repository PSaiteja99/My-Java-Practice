import java.util.Scanner;
class BouncyNumber 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number");
		int num=sc.nextInt();
		boolean isincreasing=true;
		boolean isdecreasing=true;
		int ld=num%10;
		num/=10;
		while(num>0)
		{
			int cd=num%10;
				if(ld>cd)
				{
				 isdecreasing=false;
				}
				else if (ld<cd)
				{
                  isincreasing=false;
				}
				ld=cd;
				num/=10;
			}
			if (!isincreasing && !isdecreasing)
			{
			System.out.println("Bouncy number");
			}
			else
			{
				System.out.println("not a Bouncy number");
			}
		}


	}
