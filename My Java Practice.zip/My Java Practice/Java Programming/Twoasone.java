import java.util.Scanner;
class Twoasone
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a value");
		int a=sc.nextInt();
		System.out.println("enter b value");
		int b=sc.nextInt();
		System.out.println("enter c value");
		int c=sc.nextInt();
		if((a+b==c)||(b+c==a)||(a+c==b))
		{
			 System.out.println("True");
		}
		
		else
		{
			System.out.println("FAlse");
		}



		
	}
}
