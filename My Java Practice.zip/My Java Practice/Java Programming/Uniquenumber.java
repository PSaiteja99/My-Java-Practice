import java.util.Scanner;
class Uniquenumber 
{
	public static void main(String[] args) 
	{   
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a number :");
        int n=sc.nextInt();
		boolean isUnique=true;
		while(n!=0)
		{
			int ld1=n%10;
			n=n/10;
			int temp=n;
			while (temp!=0)
			{
                int ld2=temp%10;
				if (ld2==ld1)
				{
                   isUnique=false;
				   break;
				}
                temp=temp/10;
			}
			if (isUnique==false)
			{
				break;
			}
			if (isUnique)
			{
				System.out.println("it is a unique number");
			}
			else
			{
				System.out.println("it is not a unique number");
			}
		}

	}
}