class PerfectSquare 
{
	public static void main(String[] args) 
	{
		int n=64;
		boolean isPerfectSquare=false;
			for (int i=1;i<=n ;i++ )
			{
				if (i*i==n)
				{
					isPerfectSquare=true;
					break;
				}
			}
			if (isPerfectSquare)
			{
				System.out.println("perfect square");
			}
			else
				{
				System.out.println("not a perfect square");
			}
	}
}
