class Sunnynumber 
{
	public static void main(String[] args) 
	{
		int n;
		n++;
		boolean isSunny=false;
		for (int i=1;i*i<=n;i++)
		{
			if (i*i==n)
			{
				isSunny=true;
			}
		}
		if (isSunny)
		{
			System.out.println("sunny number");
		}
		else
		{
		System.out.println("not a sunny number");
		}
	}
}
