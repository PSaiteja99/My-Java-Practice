import java.util.Scanner;
class Cigars
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no of cigars:");
		int cigars=sc.nextInt();
	    boolean isweekend=sc.nextBoolean();
        if ((isweekend==true&&cigars>=40)||(isweekend==false&&cigars>=40&&cigars<=60))
			{
            System.out.println("true");
        }
		else 
			{
           System.out.println("false");
			}
        }
    }

 