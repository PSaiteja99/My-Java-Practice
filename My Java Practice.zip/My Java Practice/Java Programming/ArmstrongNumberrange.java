
class  ArmstrongNumberrange
{
	public static void main(String[] args) 
	{
		for (int num=1;num<=1000 ;num++ )
		{
		int temp=num;
		int count =0;
		while (temp!=0)
		{
			count++;
			temp=temp/10;
		}
		temp=num;
		int sum=0;
		while (temp!=0)
		{
			int ld=temp%10;
			int prod=1;
			for (int i=1;i<=count ;i++ )
			{
				prod=prod*ld;
			}
			sum=sum+prod;
			temp=temp/10;
		}
		if (sum==num)
		{
			System.out.println(num);
		}
		}
			
	}
}