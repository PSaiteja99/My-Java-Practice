import java.util.Scanner;
class Sunnynumber2
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number:");
		int n=sc.nextInt();
		int temp=n;
		temp++;
		boolean isSunny=false;
		for (int i=1;i*i<=temp;i++)
		{
			if (i*i==temp)
			{
				isSunny=true;
			}
		}
		if (isSunny)
		{
			System.out.println(+temp+"sunny number");
		}
		else
		{
		System.out.println("not a sunny number");
		}
	}
}
