import java.util.Scanner;
class Ducknumberwith0findingposition
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		int num=sc.nextInt();
		int prod=1;
		int c=0;
		while(num!=0)
		{
			int ld=num%10;
			 prod*=ld;
			 c++;
			 if (prod==0)
			 {
				 System.out.println("0 found at:"+c+"th position from last");
				 break;
			 }
			 num=num/10;
		}
		if (prod==0)
		{
				System.out.println("Duck number");
		}
		else
			{
				System.out.println("not a Duck number");
		}

	}
}

