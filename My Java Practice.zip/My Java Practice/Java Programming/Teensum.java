import java.util.Scanner;
class Teensum 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a value");
		int a=sc.nextInt();
		System.out.println("enter b value");
		int b=sc.nextInt();
		if(a>=13&&a<=19)
		{
			System.out.println(19);
		}
		 else if(b>=13&&b<=19)
		{
			System.out.println(19);
		}
		else
		{
			System.out.println(+(a+b));
		}



	}
}
