class SumFirstAndLast
{
    public static void main(String[] args) 
    {
        int[] a = {4, 5, 2, 7, 9};
        if (a.length > 0) 
        {
            int first = a[0];
            int last = a[a.length - 1];
            int sum = first + last;
        } 
		 System.out.println("The sum of the first and last elements is: " + sum);
      
    }
}
