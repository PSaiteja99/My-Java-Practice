import java.util.Scanner;
class  StrongnumberMethodRecursion
{
	public static int Factorial(int n)
	{
		int fact=1;
		for (int i=1;i<=n;i++ )
		{
			fact=fact*i;
		}
		return fact;
	}
	public static int Sumofdigits(int n)
	{
		int sum=0;
		while (n>0)
		{
         int d=n%10;
		 sum=sum+Factorial(d);
		 n=n/10;
		}
		return sum;
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		int n=sc.nextInt();
		if (Sumofdigits(n)==n)
		{
         System.out.println("Strong number");

		}
		else
		{  		
		System.out.println("not a Strong number");

		}
	}
}
