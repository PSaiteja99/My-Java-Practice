import java.util.Scanner;

class AutomorphicNumberSum
	{
    public static void main(String[] args)
		{
        int sum = 0; 
        for (int num = 1; num <= 1000; num++) 
			{
            int temp = num;
            int square = temp * temp;
            boolean isAutomorphic = true;

           
            while (temp != 0) 
				{
                if (temp % 10 != square % 10) 
					{
                    isAutomorphic = false;
                    break;
                }
                temp = temp / 10;
                square = square / 10;
            }

          
            if (isAutomorphic)
				{
                sum += num; 
                System.out.println(num);
            }
        }

     
        System.out.println("Sum of automorphic numbers: " + sum);
    }
}
