import java.util.Scanner;
class  AreaofCircle
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the radius:");
		double r= sc.nextDouble();
		System.out.println("the area of circle is:"+3.14*r*r);
	}
}
