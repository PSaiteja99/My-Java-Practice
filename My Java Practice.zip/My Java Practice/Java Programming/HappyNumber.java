import java.util.Scanner;
class HappyNumber 
{
	public static int SumofSquaresofDigits(int n)
	{
		int sum=0;
		while(n>0)
		{
			int d=n%10;
			sum=sum+(d*d);
			n=n/10;
		}
		return sum;
	}
	public static boolean isHappynumber(int n)
	{
		if (n==1)
		return true;
		else if(n==4)
			return false;
		else
			return isHappynumber(SumofSquaresofDigits(n));
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		int n=sc.nextInt();
		if (isHappynumber(n))
		{
        	System.out.println("Happy number");
		}
		else
		{
        	System.out.println("not a Happy number");
		}
	}
}
