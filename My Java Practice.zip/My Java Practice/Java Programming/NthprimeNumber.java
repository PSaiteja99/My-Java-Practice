
import java.util.Scanner;
class NthprimeNumber 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner (System.in);
		System.out.print("ENTER THE NUMBER: ");
		int n = sc.nextInt();
		int count=0;
		
		for (int i=2;true ;i++ )
		{
			boolean isprime=true;
			for (int j=2;j<i ;j++ )
			{
				if (i%j==0)
				{
					isprime=false;
					break;
				}

			}
			if (isprime)
			{
			count++;
			if (count==n)
			{
				System.out.println(i);
				break;
			}

		}
	}
}
}
