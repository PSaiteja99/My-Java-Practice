import java.util.Scanner;
class Bill 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the price:");
		double Bill=sc.nextDouble();
		if(Bill>=5000)
		{
			System.out.println("you got 18% of discount");
			System.out.println("your final bill is:"+0.82*Bill);
		}
		else
			{
			System.out.println("you got 8% of discount");
			System.out.println("your final bill is:"+0.92*Bill);
		}
	}
}
