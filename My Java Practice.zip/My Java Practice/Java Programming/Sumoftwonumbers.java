import java.util.Scanner;
class Sumoftwonumbers 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter first number");
		double a = sc.nextDouble();
		System.out.println("Enter second number");
		double b = sc.nextDouble();
		double c=a+b;
		System.out.println("The sum of two numbers is : "+c);
		System.out.println("Enter third number");
		double d = sc.nextDouble();
		System.out.println("Enter fourth number");
		double e = sc.nextDouble();
		double f=d+e;
		System.out.println("The sum of two numbers is : "+f);
		double g=c+f;
		System.out.println(g);

	}
}
