import java.util.Scanner;
class Smallestdigit 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		int num=sc.nextInt();
		int smallest=-1;
		for (int i=0;i<=9;i++ )
		{
			int temp=num;
			while (temp>0)
			{
				int d=temp%10;
					if (d==i)
					{
					smallest=i;
					break;
					}
					temp=temp/10;
			}
			
			if (smallest==i)
			{
             break;
			}
			
		}
		System.out.println(smallest);

	}
}
