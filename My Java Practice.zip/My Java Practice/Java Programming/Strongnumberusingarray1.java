class Strongnumberusingarray1 
	{
    public static void main(String[] args)
		{
        int[] num = {145, 2, 40585, 123, 1};
        for (int n : num)
			{
            int temp = n;
            int sum = 0;
            while (temp != 0) 
				{
                int ld = temp % 10; 
                int prod = 1;
                for (int i = 1; i <= ld; i++)
					{
                    prod = prod * i;
                }
                sum = sum + prod;
                temp = temp / 10; 
            }
            if (sum == n) 
			{
            System.out.println(n + " is a Strong Number");
            }
			else 
			{
                System.out.println(n + " is not a Strong Number");
            }
        }
    }
}


