public class DateFashion 
	{
    public static int dateFashion(int you, int date)
		{
        if (you <= 2 || date <= 2)
			{
            return 0; // no
        }
		else if (you >= 8 || date >= 8) 
			{
            return 2; // yes
        } 
		else
			{
            return 1; // maybe
        }
    }

    public static void main(String[] args) {
        // Test cases
        System.out.println(dateFashion(5, 10)); // ? 2
        System.out.println(dateFashion(5, 2));  // ? 0
        System.out.println(dateFashion(5, 5));  // ? 1
    }
}
