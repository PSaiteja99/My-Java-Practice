class palindromeinrange 
{
	public static void main(String[] args) 
	{
		for (int num=1;num<=1000;num++ )
		{

		System.out.println("Enter the number:");
		int temp=num;
		int rev=0;
		while(temp!=0)
		{
			int ld=temp%10;
			rev = rev*10+ld;
			temp=temp/10;
		}
		System.out.println("revrese value:"+rev);
	    System.out.println("given number:"+num);
		if(num==rev)
		{
		System.out.println("it is a palindrome");
		}
		else
		{
			System.out.println(" it is not a palindrome");
		}
		}

	}

}

