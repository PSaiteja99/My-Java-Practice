import java.util.Scanner;
class Count0ffactors
	{
    public static int countOfFactors(int n)
	{
        int count = 0;
        for (int i = 1; i <= n; i++)		
		{
            if (n % i == 0) 
				{
                count++;
            }
        }
        return count;
    }

    public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
        System.out.println("enter a number:");
        System.out.println("Number of factors of " + num + ": " + countOfFactors(num));
    }
}


