class Switch 
{
	public static void main(String[] args) 
	{
		int a=6;
		switch (a)
		{
		case 1:System.out.println("Apple");
		break;
		case 2:System.out.println("Samsung");
		break;
		case 3:System.out.println("motrola");
		break;
		case 4:System.out.println("realme");
		break;
		case 5:System.out.println("vivo");
		break;
		default:System.out.println("Enter valid operator");		
		}
	}
}
