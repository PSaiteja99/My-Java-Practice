class productof1to5 
{
	public static void main(String[] args) 
	{
		int prod=1;
		for (int i=1;i<=5;i++ )
		{
			prod=prod*i;
			System.out.println(prod);
		}
		System.out.println(prod);
	}
}

