import java.util.Scanner;
class Sumofnumbersrecursion
{
	public static int Sumofnumbers(int a,int b)
	{
		if(a>b)
			return 0;
		else
			return a+Sumofnumbers(a+1,b);
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a start and end number:");
		int a=sc.nextInt();
		int b=sc.nextInt();
		System.out.println(Sumofnumbers(a,b));
	}
}

