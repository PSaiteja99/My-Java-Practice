class Recursion 
{
	public static String eat(String food)
	{
	System.out.println("hurrey eat  "+food);
	return "laddo";
	}
	public static void main(String[] args) 
	{
	 eat("biryani");

	}
}
