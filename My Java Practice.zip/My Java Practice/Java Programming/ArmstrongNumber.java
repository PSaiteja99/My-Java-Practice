import java.util.Scanner;
class  ArmstrongNumber
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
        System.out.println("Enter Number: ");
		int num=sc.nextInt();
		int temp=num;
		int count =0;
		while (temp!=0)
		{
			count++;
			temp=temp/10;
		}
		temp=num;
		int sum=0;
		while (temp!=0)
		{
			int ld=temp%10;
			int prod=1;
			for (int i=1;i<=count ;i++ )
			{
				prod=prod*ld;
			}
			sum=sum+prod;
			temp=temp/10;
		}
		if (sum==num)
		{
			System.out.println("it is a ArmstrongNumber ");
		}
			else 
				{
			System.out.println("it is not a ArmstrongNumber ");
		}
	}
}