import java.util.Scanner;
class  Automorphicnumberfrom1to1000 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		for(int num=1;num<=1000;num++)
		{
			int temp=num;
		   int square=temp*temp;
		boolean isAutomorphic=true;
		while(temp!=0)
		{
			if (temp%10!=square%10)
			{
				isAutomorphic=false;
				break;
			}
			temp=temp/10;
			square=square/10;
			
		}
		if(isAutomorphic)
		{
		
			System.out.println(num);
	

		}
		
	}
	}
}

