import java.util.Scanner;
class XylemandPolem 
{
	public static int reverse(int a)
	{
		int rev=0;
		while (a>0)
		{
			rev=rev*10+(a%10);
			a=a/10;
		}
		return rev;
	}
	public static int SumofDigits(int n)
	{
		int sum=0;
	
	while(n!=0)
		{
	
		sum=sum+(n%10);
		n=n/10;
		}

     return sum;

	}

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		int n=sc.nextInt();
		int ld=n%10;
		n=n/10;
		n=reverse(n);
		int fd=n%10;
		n=n/10;
		if ((fd+ld)==SumofDigits(n))
		{
		System.out.println("Xylem number");
		}
		else
		{
			System.out.println("pholem number");
		}
}
}
