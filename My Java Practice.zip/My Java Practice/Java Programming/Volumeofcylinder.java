import java.util.Scanner;
class  Volumeofcylinder
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("VOLUME OF CYLINDER");
		System.out.println("==========================");
		System.out.println("Enter HEIGHT: ");
		double h=sc.nextDouble();
		System.out.println("enter RADIUS :");
		double r=sc.nextDouble();
		System.out.println("================");
		double v=3.14*r*r*h;
		System.out.println(v);
	}
}
