import java.util.Scanner;
class Smallestnumber
	{
    public static void main(String[] args)
		{
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number:");
        int a = sc.nextInt();
        int small = 9;
        while (a != 0) 
			{
            int ld = a % 10;
            if (ld < small)
				{
                small = ld;
            }
            a = a / 10;
        }

        System.out.println("Smallest digit: " + small);
    }
}
