import java.util.Scanner;
class CountRecursion 
{
	public static int countofdigits(int n)
	{
		if(n==0)
			return 0;
		else
			return 1+countofdigits(n/10);
	}
	/*public static void main(String[] args) 
	{
		System.out.println(countofdigits(721973));
	}
}*/
public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number:");
		int n=sc.nextInt();
		System.out.println(countofdigits(n));
	}
}
