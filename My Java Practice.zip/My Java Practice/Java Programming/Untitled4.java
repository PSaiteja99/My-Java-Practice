class Recursion 
{
	public static void eat(String food)
	{
	    eat("hurret eat"+food);
	}
	public static void main(String[] args) 
	{
		System.out.println("biryani");
	}
}
