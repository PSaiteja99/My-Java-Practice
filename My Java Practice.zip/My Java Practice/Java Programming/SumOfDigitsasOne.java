import java.util.Scanner;

class SumOfDigitsasOne 
	{
    public static void main(String[] args)
		{
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number");
        int num = sc.nextInt();

        while (true) 
			{
            int sum = 0;
            while (num > 0)
				{
                int d = num % 10;
                sum = sum + d;
                num = num / 10;
            }
            num = sum;
            if (num <= 9) 
				{
                break;
            }

        }
        if (num == 1)
            System.out.println("Sum of digits is recursively calculated as one");

        else
            System.out.println("Sum of digits is not recursively calculated as one");
    }

}