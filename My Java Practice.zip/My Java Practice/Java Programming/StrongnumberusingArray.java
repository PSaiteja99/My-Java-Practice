class StrongnumberusingArray
	{
    public static void main(String[] args)
		{
        int[] num = {145, 231, 123, 5343, 56543};
		for (int num=a )
		{
            int temp = a;
            int sum = 0;
            while (temp != 0) 
				{
                int ld = temp % 10;  
                int prod = 1;
                for (int i = 1; i <= ld; i++) 
					{
                    prod = prod * i;
                }
                sum = sum + prod;
                temp = temp / 10;
            }
            if (sum == a)
				{
                System.out.println(a + " is a Strong Number");
            } 
			else 
				{
                System.out.println(a + " is not a Strong Number");
            }
        }
    }
	}
