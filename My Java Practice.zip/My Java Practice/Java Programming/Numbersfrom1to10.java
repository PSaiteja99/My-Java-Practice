class Numbersfrom1to10
{
	public static void main(String[] args) 
	{
		for(int i=1;i<=10;i++)
		{
		System.out.println(i);
		}
		for (int i=100;i>=1;i--)
		{
			System.out.println(i);
		}

	}
}
