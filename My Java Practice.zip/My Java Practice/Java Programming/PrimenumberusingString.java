import java.util.Scanner;
class PrimenumberusingString
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		int n = sc.nextInt();
		String v="prime number"; 
		for (int i=2;i<n;i++)
		{
			if (n%i==0)
			{
			v="not a prime number";
			break;
			}
		}
        System.out.println(v);
	}
}
