import java.util.Scanner;
class  DiasriumNumber
{
	public static int countofdigits(int n)
	{
		int c=0;
		while (n>0)
		{
			c++;
			n=n/10;
		}
		return c;
	}
	public static int Exponential(int base,int power)
	{
		int e=1;
		for (int i=1;i<=power;i++ )
		{
			e=e*base;
		}
		return e;
	}
	public static int SumofDigits(int n)
	{
		int sum=0;
		while (n>0)
		{
			int d=n%10;
			int count=countofdigits(n);
			sum=sum+Exponential(d,count);
			n=n/10; 
		}
		return sum;
	}


	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number:");
		int n=sc.nextInt();
		if (SumofDigits(n)==n)
		{
			System.out.println("Disarium number");
		}
		else
		{
			System.out.println(" not a Disarium number");
		}
	}
}
