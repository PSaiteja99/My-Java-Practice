import java.util.Scanner;
class BouncyNumberusingMethod
	{
    public static void main(String[] args) 
		{
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number:");
        int num = sc.nextInt();
        boolean isBouncy = isBouncyNumber(num);
        if (isBouncy) 
		{
           System.out.println("Bouncy number");
        } 
		else 
			{
            System.out.println("Not a Bouncy number");
        }
    }

    public static boolean isBouncyNumber(int num) 
		{
        String numStr = Integer.toString(num);
        boolean isIncreasing = true;
        boolean isDecreasing = true;

        for (int i = 0; i < numStr.length() - 1; i++)
			{
            if (numStr.charAt(i) < numStr.charAt(i + 1))
				{
                isDecreasing = false;
            } 
			else if (numStr.charAt(i) > numStr.charAt(i + 1))
				{
                isIncreasing = false;
            }
        }

        return !isIncreasing && !isDecreasing;
    }
}

