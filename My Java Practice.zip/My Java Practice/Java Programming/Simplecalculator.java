import java.util.Scanner;
class Simplecalculator 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a value:");
		int a=sc.nextInt();
		System.out.println("enter b value:");
		int b=sc.nextInt();
		System.out.println("enter arthematic operator:");
		char op=sc.next().charAt(0);
		if(op=='+')
		{
			System.out.println(+(a+b));
		}
		else if(op=='-')
		{
			System.out.println(+(a-b));
		}
		else if(op=='*')
		{
			System.out.println(+(a*b));
		}
		else if(op=='/')
		{
			System.out.println(+(a/b));
		}
		else if(op=='%')
		{
			System.out.println(+(a%b));
		}
		else
		{
			System.out.println("enter correct value");
		}
	}
}
