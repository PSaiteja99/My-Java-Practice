import java.util.Scanner;
class StrongNumberArray
	{
    public static void main(String[] args)
		{
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of elements in the array:");
        int size = sc.nextInt();
        int[] arr = new int[size];
        System.out.println("Enter the numbers:");
        for (int i = 0; i < size; i++) 
			{
            arr[i] = sc.nextInt();
        }
        for (int num : arr)
			{
            int temp = num;
            int sum = 0;
            
          
            while (temp != 0) {
                int ld = temp % 10;
                int prod = 1;
                
                // Calculate the factorial of the digit
                for (int i = 1; i <= ld; i++)
					{
                    prod = prod * i;
                }
                
                // Add factorial to the sum
                sum = sum + prod;
                temp = temp / 10;
            }
            
            // Check if the sum is equal to the original number
            if (sum == num) {
                System.out.println(num + " is a Strong Number");
            } else {
                System.out.println(num + " is not a Strong Number");
            }
        }
        
        sc.close();
    }
}
