class Ifelse 
{
	public static void main(String[] args) 
	{
		int a=6;
		if (a<20)
		{
         System.out.println("Hello World!");
		}
		else
		{
		System.out.println("Hello World!");
		}
	}
}
