import java.util.Scanner;
class Positivenegative
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number:");
		int n=sc.nextInt();
		if (n>0)
		{
         System.out.println(n+"is an positive number");
		}
		else if(n<0) 
			{
         System.out.println(n+"is an negative number");
		}
		else 
			{
         System.out.println(n+"is an neutral number");
		}
	}
}
