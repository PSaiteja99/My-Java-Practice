import java.util.Scanner;
class Summation 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter array size:");
		int size=sc.nextInt();
		int[] a=new int[size];
		int sum=0;
		for (int i=0;i<=a.length-1;i++)
		{
         System.out.println("enter the element in an index " +i);
		 a[i]=sc.nextInt();
		}
		for (int i=0;i<=a.length-1;i++)
			{	
			    sum=sum+a[i];
			}
			System.out.println(sum);


	}
}

