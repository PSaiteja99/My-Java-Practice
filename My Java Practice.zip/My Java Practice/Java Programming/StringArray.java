class StringArray 
{
	public static void main(String[] args) 
	{
		String[] S=new String[4];
		S[0]="hi";
		S[1]="hello";
		S[2]="kumar";
		S[3]="vybhav";
		System.out.println(S[0]);
		System.out.println(S[1]);
		System.out.println(S[2]);
		System.out.println(S[3]);
	}
}
