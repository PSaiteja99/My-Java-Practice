import java.util.Scanner;
class Spynumber
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		int num=sc.nextInt();
		int sum=0;
		int prod=1;
		while(num!=0)
		{
			int ld=num%10;
			sum+=ld;
		    prod*=ld;
			num=num/10;
		}
		if (sum==prod)
		{
				System.out.println("spy number");
		}
		else
			{
				System.out.println("not a spy number");
		}

	}
}
