class Circle_program {
    public static void main(String[] args) {

        Circle r1 = new Circle();
        Circle r2 = new Circle();

        r1.radius = 8;
        r2.radius = 10;
        double area1 = Circle.PI * r1.radius * r2.radius;
        double area2 = Circle.PI * r2.radius * r2.radius;

        double circumference1 = 2 * Circle.PI * r1.radius;
        double circumference2 = 2 * Circle.PI * r2.radius;

        System.out.println("--------------Circle 1 --------------------------");
        System.out.println("PI Value : " + Circle.PI);
        System.out.println("Radius value : " + r1.radius);
        System.out.println("Area of a circle : " + area1);
        System.out.println("Circumference value : " + circumference1);

        System.out.println("--------------Circle 2 --------------------------");
        System.out.println("PI Value : " + Circle.PI);
        System.out.println("Radius value : " + r2.radius);
        System.out.println("Area of a circle : " + area2);
        System.out.println("Circumference value : " + circumference2);

    }
}