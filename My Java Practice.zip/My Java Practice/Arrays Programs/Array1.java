class Array1
{
	public static void main(String[] args) 
	{
		int[] A=new int[5];
		A[0]=7;
		A[1]=3;
		A[2]=4;
		A[3]=8;
		A[4]=1;
		System.out.println(A[0]);
		System.out.println(A[1]);
		System.out.println(A[2]);
		System.out.println(A[3]);
		System.out.println(A[4]);
	}
}
