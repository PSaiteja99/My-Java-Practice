class IntroductionArray {
    public static void main(String[] args) {
        int[] array = new int[6];
        array[0] = 2;
        array[1] = 8;
        array[2] = 0;
        array[3] = 6;
        array[4] = 0;
        array[5] = 2;

        System.out.println(array[0]);
        System.out.println(array[1]);
        System.out.println(array[2]);
        System.out.println(array[3]);
        System.out.println(array[4]);
        System.out.println(array[5]);

    }
}