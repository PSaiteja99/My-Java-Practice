import java.util.*;
class  AscendingOrderMethod
{
    public static int sorting(int num)
	{
		int sort=0;
		for (int i=1;i<=9;i++)
		{
			int temp=num;
			while(temp>0)
			{
				int d=temp%10;
				if (i==d)
				{
					sort=sort*10+d;
				}
				temp=temp/10;
			}
			}
			return sort;
	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number:");
		int num=sc.nextInt();
		System.out.println(sorting(num));
	}
}
