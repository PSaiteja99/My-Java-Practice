import java.util.Scanner;

class MergingTwoArrays {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] array1 = new int[4];
        int[] array2 = new int[5];
        int[] array3 = new int[10];

        int i;
        for (i = 0; i <= array1.length; i++) {
            array1[i] = sc.nextInt();
        }
        int j;
        for (j = 0; j <= array2.length; j++) {
            array2[j] = sc.nextInt();
        }
        int k;
        for (k = 0; k <= array3.length - 1; k++) {
            array3[k] = array1[i] + array2[j];
        }
        System.out.println(array3);
    }

}
