import java.util.Scanner;

class ReverseValues {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] array = new int[5];

        for (int i = 0; i <= array.length - 1; i++) {
            System.out.println("Enter values in index " + i + " Which has to be reversed");
            array[i] = sc.nextInt();
        }

        for (int i = array.length - 1; i >= 0; i--) {
            System.out.println("****************************************************************");
            System.out.println(array[i]);
        }

    }

}
