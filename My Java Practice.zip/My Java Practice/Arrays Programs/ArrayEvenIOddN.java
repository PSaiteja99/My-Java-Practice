import java.util.Scanner;

class ArrayEvenIOddN {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a size of an array");
        int size = sc.nextInt();
        int[] array = new int[size];

        for (int i = 0; i <= array.length - 1; i++) {
            System.out.println("Enter an element in index " + i + " : ");
            array[i] = sc.nextInt();
        }

        for (int i = 1; i <= array.length; i++) {
            if (i % 2 == 0) {
                if (array[i] % 2 != 0) {
                    System.out.println(array[i]);
                }
            }
        }
    }

}
