class Circle {
    public static double PI = 3.14;
    public int radius;
}