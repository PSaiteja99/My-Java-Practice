class Rectangle {
    public static String Color = "Blue";
    public int length;
    public int width;
}
