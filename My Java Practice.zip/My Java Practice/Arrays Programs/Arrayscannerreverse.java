import java.util.Scanner;
class Arrayscannerreverse
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter array size:");
		int size=sc.nextInt();
		int[] a=new int[size];
		for (int i=0;i<=a.length-1;i++ )
		{
			System.out.println("enter array element at index"+i+"is:");
			a[i]=sc.nextInt();
		}
		for (int i=a.length-1;i>=0;i--)
		{
			System.out.println(a[i]);
		}
	}
}
