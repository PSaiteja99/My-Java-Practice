package 
import java.util.Scanner;
public class ArrayProductAndPrimeSum 
{
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();
        int[] arr = new int[n];
        int sum = 0;
        long product = 1;
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++)
        {
            arr[i] = scanner.nextInt();
            sum += arr[i];
            product *= arr[i];
        }

        System.out.println("Product of elements: " + product);
        System.out.println("Sum of elements: " + sum);

        boolean isPrime = true;
        if (sum <= 1) {
            isPrime = false;
        } else {
            for (int i = 2; i <= Math.sqrt(sum); i++) {
                if (sum % i == 0) {
                    isPrime = false;
                    break;
                }
            }
        }

        if (isPrime)
        {
            System.out.println("The sum of elements is prime.");
        } 
        
        else 
        {
            System.out.println("The sum of elements is not prime.");
        }

        scanner.close();
    }
}
