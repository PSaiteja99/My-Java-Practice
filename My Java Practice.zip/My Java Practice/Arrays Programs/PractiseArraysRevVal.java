import java.util.Scanner;

class PractiseArraysFloatVal
{
	public static void main( String args [] )
	{
		Scanner sc = new Scanner( System.in );
		System.out.print("Enter the size of array : ");
		int size = sc.nextInt();

		float[] array = new float[ size ];
		
		for( int i = 0; i <= array.length - 1; i++ )
		{
			System.out.print("Enter decimal value that has to be stored in index " + i  + " : ");
			array[i] = sc.nextFloat();
		}
	
		for( int i = 0; i <= array.length -1 ; i++)
		{

			System.out.println("The value stored in the index " + i + " is " + array[i]);
		}
	}
}
		