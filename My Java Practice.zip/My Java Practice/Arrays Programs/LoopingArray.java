import java.util.Scanner;

class LoopingArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a Size for an array: ");
        int size = sc.nextInt();
        int[] array = new int[size];

        for (int i = 0; i <= array.length - 1; i++) {
            System.out.println("Enter an array in the index " + i);
            array[i] = sc.nextInt();

        }

        for (int i = 0; i <= array.length - 1; i++) {
            System.out.println(array[i]);
        }

    }

}
