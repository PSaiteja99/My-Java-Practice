class ReverseString {
    public static void main(String[] args) {
        String str = "Perumalla Sireesh Kumar";
        String[] reverse = str.split(" ");

        for (int i = 0; i < reverse.length; i++) {
            StringBuilder sb = new StringBuilder(reverse[i]);
            reverse[i] = sb.reverse();
            System.out.println(reverse[i]);
        }
    }

}
