class SplitingString {
    public static void main(String[] args) {
        String str = "This is india";
        String[] words = str.split(" ");

        for (int i = 0; i < words.length; i++) {
            System.out.println(words[i].charAt(0));

        }

    }

}
