class Rectangle_program {
    public static void main(String[] args) {
        Rectangle r1 = new Rectangle();
        Rectangle r2 = new Rectangle();

        Rectangle n1 = new Rectangle();
        Rectangle n2 = new Rectangle();

        r1.length = 10;
        r2.width = 5;
        int area1 = r1.length * r2.width;

        n1.length = 8;
        n2.width = 4;
        int area2 = n1.length * n2.width;

        double conversion1 = area1 / 10;
        double conversion2 = area2 / 10;

        System.out.println("----------Rectangle-1-----------");
        System.out.println("Length of rectangle : " + r1.length);
        System.out.println("Width of rectangle : " + r2.width);
        System.out.println("Color of Rectangle " + Rectangle.Color);
        System.out.println("Area of rectangle 1: " + area1);
        System.out.println("Conversion to cm: " + conversion1);

        System.out.println("----------Rectangle-2-----------");

        System.out.println("Length of rectangle : " + n1.length);
        System.out.println("Width of rectangle : " + n2.width);
        System.out.println("Color of Rectangle " + Rectangle.Color);
        System.out.println("Area of rectangle 1: " + area2);
        System.out.println("Conversion to cm: " + conversion2);

    }
}
