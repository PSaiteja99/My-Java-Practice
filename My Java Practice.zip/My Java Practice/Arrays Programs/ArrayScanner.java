import java.util.Scanner;
class ArrayScanner 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter array size:");
		int size=sc.nextInt();
		int[] kumar=new int[size];
		for (int i=0;i<=kumar.length-1;i++)
		{
         System.out.println("enter the element in an index"+i);
		 kumar[i]=sc.nextInt();
		}
		for (int i=0;i<=kumar.length-1;i++)
		{
		System.out.println(kumar[i]);
		}

	}
}

