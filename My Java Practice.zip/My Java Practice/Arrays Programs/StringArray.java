class StringArray {
    public static void main(String[] args) {
        String[] array1 = new String[4];
        array1[0] = "HI";
        array1[1] = "Sireesh";
        array1[2] = "Kumar";
        array1[3] = "Perumalla";

        System.out.println(array1[1]);
        System.out.println(array1[2]);
        System.out.println(array1[3]);
        System.out.println(array1[0]);

    }

}
