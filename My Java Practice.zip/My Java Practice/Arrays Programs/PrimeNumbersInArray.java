import java.util.Scanner;

class PrimeNumbersInArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter array size:");
        int size = sc.nextInt();
        int[] a = new int[size];
        for (int i = 0; i <= a.length - 1; i++) {
            System.out.println("enter the element in an index" + i);
            a[i] = sc.nextInt();
        }
        for (int i = 0; i <= a.length - 1; i++) {
            int count = 0;
            for (int j = 1; j <= a[i]; j++) {
                if (a[i] % j == 0) {
                    count++;
                }
            }
            if (count == 2) {
                System.out.println(a[i]);
            }
        }
    }
}